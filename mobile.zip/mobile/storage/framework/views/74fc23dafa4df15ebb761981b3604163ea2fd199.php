<ul class="sidebar navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="/head/dashboard">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('category.index')); ?>">
          <i class="fas fa-fw fa-table"></i>
          <span>Category</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('brand.index')); ?>">
          <i class="fas fa-fw fa-table"></i>
          <span>Brand</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('item.index')); ?>">
          <i class="fas fa-fw fa-table"></i>
          <span>Item</span></a>
      </li>
      <?php if(Auth::check() && (Auth::user()->role=='head' || Auth::user()->role=='admin')): ?>
       
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('user.index')); ?>">
          <i class="fas fa-fw fa-chart-area"></i>
          <span>User</span></a>
      </li>
        
      <?php endif; ?>

      <?php if(Auth::check() && Auth::user()->role=='admin'): ?>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('product.index')); ?>">
          <i class="fas fa-fw fa-table"></i>
          <span>Product</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('category.index')); ?>">
          <i class="fas fa-fw fa-table"></i>
          <span>Category</span></a>
      </li>
       <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('price.index')); ?>">
          <i class="fas fa-fw fa-table"></i>
          <span>Price</span></a>
      </li>
      <?php endif; ?>

      <?php if(Auth::check() && (Auth::user()->role=='head' || Auth::user()->role=='agent') ): ?>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('order.index')); ?>">
          <i class="fas fa-fw fa-table"></i>
          <span>Order</span></a>
      </li>
      <?php endif; ?>
      <?php if(Auth::check() && (Auth::user()->role=='admin' || Auth::user()->role=='head')): ?>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('orderReturn.index')); ?>">
          <i class="fas fa-fw fa-table"></i>
          <span>Order Return</span></a>
      </li>
      
      <?php endif; ?>
      <?php if(Auth::check() && (Auth::user()->role=='admin' || Auth::user()->role=='head')): ?>
       <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('orderRequest.index')); ?>">
          <i class="fas fa-fw fa-table"></i>
          <span> Order Request</span></a>
      </li>
     <?php endif; ?>
    </ul>
<?php /**PATH C:\xampp\htdocs\os\resources\views/sidebar.blade.php ENDPATH**/ ?>