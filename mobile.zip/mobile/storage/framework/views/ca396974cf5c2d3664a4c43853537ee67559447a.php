<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		<h1>Category </h1>
		<form action="<?php echo e(route('brand.store')); ?>" method="post" enctype="multipart/form-data">
			<?php echo csrf_field(); ?>
			<div class="row mt-5">
				<div class="col-md-3 ">
				<label>Brand Name</label>
			</div>
			<div class="col-md-5">
				<input type="name" name="name" class="form-control">
			</div>
			<div class="col-md-3">
				<input type="submit" value="ADD">
			</div>
			</div>
			
		</form>
		
		

	<div class="col-md-8 offset-2 mt-5">

		<table class="table table-dark table-sm">
			<tr>
				<th>NO.</th>
				<th>Brand Name</th>
				<th>Action</th>
			</tr>
			<?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($brand->id); ?></td>
				<td><?php echo e($brand->name); ?></td>
				 <td>
                      <form action="<?php echo e(route('brand.destroy',$brand->id)); ?>" method="post">
                        <?php echo method_field('Delete'); ?>
                        <?php echo csrf_field(); ?>
                        <input type="submit" name="btnsubmit" value="Delete" class="btn btn-danger">
                      </form>
                  </td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</table>
	</div>
		
	</div>
	
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backtemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mobile\resources\views/brand.blade.php ENDPATH**/ ?>