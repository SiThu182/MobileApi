<ul class="sidebar navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="/head/dashboard">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="{{route('category.index')}}">
          <i class="fas fa-fw fa-table"></i>
          <span>Category</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="{{route('brand.index')}}">
          <i class="fas fa-fw fa-table"></i>
          <span>Brand</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="{{route('type.index')}}">
          <i class="fas fa-fw fa-table"></i>
          <span>Type</span></a>
      </li>
       <li class="nav-item">
        <a class="nav-link" href="{{route('specification.index')}}">
          <i class="fas fa-fw fa-table"></i>
          <span>Specification</span></a>
      </li>

      
    </ul>
